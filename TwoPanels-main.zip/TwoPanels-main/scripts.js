function show(){
    document.getElementById("panel-1").style.display = "none";
    document.getElementById("panel-2").style.display = "block";
}

function hide(){
    document.getElementById("panel-1").style.display = "block";
    document.getElementById("panel-2").style.display = "none";
}